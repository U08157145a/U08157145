/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{   
    int a;
    int b;
    int sum;
    printf("No.1:");
    scanf("%d",&a);
    printf("No.2:");
    scanf("%d",&b);
    sum=a+b;
    printf("No.1 is %d\nNo.2 is %d\nSum is %d\n",a,b,a+b);
    printf("%d",sum);


    return 0;
}
